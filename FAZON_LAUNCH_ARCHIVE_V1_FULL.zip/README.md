# FAZON Project

Public overview of the FAZON Engine and Codex structure.