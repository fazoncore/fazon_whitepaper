This is the extended version of the FAZON patent README.
Includes additional materials and documentation.