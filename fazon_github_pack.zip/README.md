# FAZON Whitepaper (Zenodo Version)

This repository contains the open-access version of the FAZON Book I: The Theory of Coincidence.

## 📘 Publication
- DOI: [10.5281/zenodo.15716698](https://doi.org/10.5281/zenodo.15716698)
- Published via Zenodo
- PDF: `ZENODO_X_FA_FINAL.pdf`

## 🛡️ Access Notice
The full version (with STRATA, SUPRADECK, NFT access) is only available through verified NFT distribution.

## 📎 Authors
- Miki Goldman (ORCID: [0009-0005-9253-3916](https://orcid.org/0009-0005-9253-3916))
- FAZON Project © 2025
